package com.laioffer.dropnext;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DropnextApplication {

    public static void main(String[] args) {
        SpringApplication.run(DropnextApplication.class, args);
    }

}
