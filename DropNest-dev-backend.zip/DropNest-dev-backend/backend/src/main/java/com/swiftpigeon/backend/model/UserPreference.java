package com.swiftpigeon.backend.model;

public enum UserPreference {
    SPEED_FIRST,
    COST_FIRST
}
