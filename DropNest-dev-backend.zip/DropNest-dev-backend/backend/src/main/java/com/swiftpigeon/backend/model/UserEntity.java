package com.swiftpigeon.backend.model;


import jakarta.persistence.*;


import java.util.Objects;


@Entity
@Table(name = "users")
public class UserEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String username;
    private String password;
    @Enumerated(EnumType.STRING)
    private com.swiftpigeon.backend.model.UserRole role;


    public UserEntity() {
    }


    public UserEntity(Long id, String username, String password, com.swiftpigeon.backend.model.UserRole role) {
        this.id = id;
        this.username = username;
        this.password = password;
        this.role = role;
    }


    public String getPassword() {
        return password;
    }


    public String getUsername() {
        return username;
    }


    public Long getId() {
        return id;
    }


    public com.swiftpigeon.backend.model.UserRole getRole() {
        return role;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        UserEntity that = (UserEntity) o;
        return Objects.equals(id, that.id) && Objects.equals(username, that.username) && Objects.equals(password, that.password) && role == that.role;
    }


    @Override
    public int hashCode() {
        return Objects.hash(id, username, password, role);
    }


    @Override
    public String toString() {
        return "UserEntity{" +
                "id=" + id +
                ", username='" + username + '\'' +
                ", password='" + password + '\'' +
                ", role=" + role +
                '}';
    }
}

