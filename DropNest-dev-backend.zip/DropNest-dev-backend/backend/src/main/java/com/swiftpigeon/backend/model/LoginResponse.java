package com.swiftpigeon.backend.model;

public record LoginResponse(
        String token
) {
}
