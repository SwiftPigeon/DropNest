package com.swiftpigeon.backend.model;
public record LoginRequest(
        String username,
        String password
) {
}
