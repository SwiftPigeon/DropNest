package com.swiftpigeon.backend.model;

public enum UserRole {
    USER,
    ADMIN
}

