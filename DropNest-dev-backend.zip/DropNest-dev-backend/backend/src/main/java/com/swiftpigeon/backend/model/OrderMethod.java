package com.swiftpigeon.backend.model;

public enum OrderMethod {
    ROBOT,
    DRONE
}
